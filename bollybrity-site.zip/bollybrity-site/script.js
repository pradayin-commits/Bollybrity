const products = [
 {name:'Boss Icon', gender:'Men', notes:'Bergamot • Black Pepper • Oud • Leather', price:2999, img:'assets/bottle-close.jpeg'},
 {name:'Midnight Star', gender:'Men', notes:'Tobacco • Vanilla • Amber • Dark Woods', price:3499, img:'assets/bottle-lounge.jpeg'},
 {name:'Royal Legacy', gender:'Men', notes:'Saffron • Sandalwood • Musk • Incense', price:3999, img:'assets/bottle-close.jpeg'},
 {name:'Dark Emperor', gender:'Men', notes:'Smoky Oud • Patchouli • Cedar • Spice', price:4499, img:'assets/bottle-lounge.jpeg'},
 {name:'Golden Diva', gender:'Women', notes:'Jasmine • Rose • Vanilla • Amber', price:2999, img:'assets/bottle-lounge.jpeg'},
 {name:'Velvet Queen', gender:'Women', notes:'White Musk • Peony • Amber • Silk Woods', price:3499, img:'assets/bottle-close.jpeg'},
 {name:'Starlight', gender:'Women', notes:'Citrus • Floral Aura • Sandalwood • Musk', price:3999, img:'assets/bottle-lounge.jpeg'},
 {name:'Majestic', gender:'Women', notes:'Pear • Jasmine • Oud • Golden Vanilla', price:4499, img:'assets/bottle-close.jpeg'}
];
const grid=document.getElementById('products');
const cart=[];
function renderProducts(){grid.innerHTML=products.map((p,i)=>`<article class="product reveal"><span class="tag">${p.gender}</span><img src="${p.img}" alt="${p.name} BollyBrity perfume"><h3>${p.name}</h3><p class="notes">${p.notes}</p><div class="price">₹${p.price.toLocaleString('en-IN')}</div><button class="add" onclick="addToCart(${i})">Add To Cart</button></article>`).join('')}
function addToCart(i){cart.push(products[i]);renderCart();document.getElementById('cart').classList.add('open')}
function renderCart(){document.getElementById('cartCount').textContent=cart.length;document.getElementById('cartItems').innerHTML=cart.map(p=>`<div class="cart-item"><span>${p.name}</span><strong>₹${p.price.toLocaleString('en-IN')}</strong></div>`).join('')||'<p>Your cart is empty.</p>';document.getElementById('cartTotal').textContent='₹'+cart.reduce((s,p)=>s+p.price,0).toLocaleString('en-IN')}
document.getElementById('openCart').onclick=()=>document.getElementById('cart').classList.add('open');
document.getElementById('closeCart').onclick=()=>document.getElementById('cart').classList.remove('open');
renderProducts();renderCart();
const io=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting)e.target.classList.add('visible')}),{threshold:.12});
document.querySelectorAll('.reveal').forEach(el=>io.observe(el));
